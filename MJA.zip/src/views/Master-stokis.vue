<template>
    <div class="master-stokis">
        <!-- Background -->
        <div class="z offset-lg-6 col-lg-6 offset-md-4 col-md-8 -mt-n wow fadeInRight">
            <img class="mt-bg" :src="require ('@/assets/images/beranda/bg-section-1.png')" alt="">
        </div>

        <!-- START DAFTAR STOKIS -->
        <div class="sec-stokis ">
            <div class="container">
                <div class="text-center mb-5">
                    <img class="img-fluid wow fadeInDown" data-wow-delay="200ms" :src="require ('@/assets/images/daftar stokis/ilus-daftar-stokis-mja.png')" alt="">
                    <h3 class="font-weight-bold l-s wow fadeInUp" data-wow-delay="400ms">DAFTAR MASTER STOKIS MJA</h3>
                    <h6 class="text-abumuda wow fadeInUp" data-wow-delay="600ms">DAFTAR LOKASI STOKIS UNTUK MJA</h6>
                </div>
            </div>
        </div>
        <!-- END DAFTAR STOKIS -->

        <!-- START MASTER -->
        <div class="container">
            <div class="row align-items-center justify-content-center mt-section">
                <div class="col-lg-7 col-md-6 col-12 wow fadeInLeft" data-wow-delay="800ms">
                    <img class="img-fluid" :src="require ('@/assets/images/master stokis/sumatera-utara.png')" alt="">
                    <img class="img-fluid loc1" :src="require ('@/assets/images/master stokis/location.png')" alt="">
                    <img class="img-fluid loc-gray1-1" :src="require ('@/assets/images/master stokis/location-grey.png')" alt="">
                    <img class="img-fluid loc-gray1-2" :src="require ('@/assets/images/master stokis/location-grey.png')" alt="">
                    <img class="img-fluid loc-gray1-3" :src="require ('@/assets/images/master stokis/location-grey.png')" alt="">
                </div>
                <div class="col-lg-4 col-md-6 col-10">
                    <div class="text-center wow fadeInRight" data-wow-delay="100ms">
                        <h5 class="font-weight-bold mb-3 mt-5 mt-md-0">MASTER STOKIS PROVINSI SUMATRA</h5>
                        <div class="card-artikel mb-5">
                            <div class="card-body">
                                <iframe class="img-fluid"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3981.8095119166596!2d98.50019091447308!3d3.6309284973579166!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30312a19bf624bf5%3A0xdc7b88359247e797!2sJl.%20Teratai%20No.138%2C%20Nangka%2C%20Kec.%20Binjai%20Utara%2C%20Kota%20Binjai%2C%20Sumatera%20Utara%2020743!5e0!3m2!1sen!2sid!4v1621493764224!5m2!1sen!2sid"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                <h3 class="font-weight-bold mt-3">SUMATRA UTARA</h3>
                                <p class="text-ijo">Bapak Ahmad Syahri</p>
                                <p class="text-abumuda">Jl. Teratai No.138 Lk 7 Kec. Binjai Utara Kota Banjai Sumut 20743
                                </p>
                                <p class="text-abu font-weight-bold">081387635761</p>
                                <div class="mt-4 mb-2">
                                    <a href="" class="btn-bg-ijo rounded-15 py-2 px-4"><i
                                            class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Background -->
        <div class="z bg-1-2 wow fadeInLeft">
            <img class="img-bg-kiri" :src="require ('@/assets/images/beranda/bg-section-2-3.png')" alt="">
        </div>

        <div class="container -mt-section-2">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-6 offset-lg-1 mt-section d-md-none d-block wow fadeIn">
                    <img class="img-fluid" :src="require ('@/assets/images/master stokis/jawa-barart.png')" alt="">
                    <img class="img-fluid loc2" :src="require ('@/assets/images/master stokis/location.png')" alt="">
                    <img class="img-fluid loc-gray2-1" :src="require ('@/assets/images/master stokis/location-grey.png')" alt="">
                </div>

                <div class="col-lg-4 col-md-6 col-10">
                    <div class="text-center wow fadeInLeft" data-wow-delay="200ms">
                        <h5 class="font-weight-bold mb-3 mt-5 mt-md-0">MASTER STOKIS PROVINSI JAWA</h5>
                        <div class="card-artikel mb-5">
                            <div class="card-body">
                                <iframe class="img-fluid"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.15650233651!2d107.10288551448546!3d-6.373787395387884!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69997bb22f427f%3A0x929dcd27bfdb7033!2sPerumahan%20Telaga%20Pasiraya!5e0!3m2!1sen!2sid!4v1621494992991!5m2!1sen!2sid"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                <h3 class="font-weight-bold mt-3">JAWA BARAT</h3>
                                <p class="text-ijo">Bapak Edi Sahidi</p>
                                <p class="text-abumuda">Perumahan Telaga Pasiraya Blok AC 12A No.19 DS Sukasari Kec. Serang
                                    Baru Kota Bekasi Jawa Barat</p>
                                <p class="text-abu font-weight-bold">085678345673</p>
                                <div class="mt-4 mb-2">
                                    <a href="" class="btn-bg-ijo rounded-15 py-2 px-4"><i
                                            class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 offset-lg-1 d-none d-md-block wow fadeInRight" data-wow-delay="400ms">
                    <img class="img-fluid" :src="require ('@/assets/images/master stokis/jawa-barart.png')" alt="">
                    <img class="img-fluid loc2" :src="require ('@/assets/images/master stokis/location.png')" alt="">
                    <img class="img-fluid loc-gray2-1" :src="require ('@/assets/images/master stokis/location-grey.png')" alt="">
                </div>
            </div>
        </div>

        <!-- Backgroung 3-4 -->
        <div class="offset-10 col-2 z bg-1-2 -mt-section d-lg-block d-none wow fadeInRight">
            <img class="img-bg-kanan" :src="require ('@/assets/images/beranda/bg-section-3-4.png')" alt="">
        </div>

        <div class="container -mt-section-2">
            <div class="row align-items-center justify-content-center">
                <div class="col-lg-7 col-md-6 mt-7 wow fadeInLeft" data-wow-delay="200ms">
                    <img class="img-fluid" :src="require ('@/assets/images/master stokis/kalimantan-barat.png')" alt="">
                    <img class="img-fluid loc3" :src="require ('@/assets/images/master stokis/location.png')" alt="">
                </div>
                <div class="col-lg-4 col-md-6 col-10 wow fadeInRight" data-wow-delay="400ms">
                    <div class="text-center">
                        <h5 class="font-weight-bold mb-3 mt-5 mt-md-0">MASTER STOKIS KALIMANTAN</h5>
                        <div class="card-artikel mb-5">
                            <div class="card-body">
                                <iframe class="img-fluid"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1994.9086338746831!2d109.31316919271161!3d-0.04161898456712151!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e1d591bcbb7dbef%3A0xf63c660ce2043d15!2sVermak%20Levis!5e0!3m2!1sen!2sid!4v1621496688448!5m2!1sen!2sid"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                <h3 class="font-weight-bold mt-3">KALIMANTAN BARAT</h3>
                                <p class="text-ijo">Bapak Alim Anshary</p>
                                <p class="text-abumuda">Jl. Dr.Sutomo No.7 Kel.Sel Bangkong Kec.Pontianak Kota, Kota
                                    Pontianak, Kalimantan Barat</p>
                                <p class="text-abu font-weight-bold">085679841273</p>
                                <div class="mt-4 mb-2">
                                    <a href="" class="btn-bg-ijo rounded-15 py-2 px-4"><i
                                            class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Background -->
        <div class="z bg-1-2 wow fadeInLeft">
            <img class="img-bg-kiri" :src="require ('@/assets/images/beranda/bg-section-4-5.png')" alt="">
        </div>

        <div class="container -mt-section-2">
            <div class="row align-items-center justify-content-center">
                <div class="col-md-6 offset-lg-1 d-md-none d-block mt-5 wow fadeIn">
                    <img class="img-fluid" :src="require ('@/assets/images/master stokis/sulawesi-tengah.png')" alt="">
                    <img class="img-fluid loc-gray4-1" :src="require ('@/assets/images/master stokis/location-grey.png')" alt="">
                    <img class="img-fluid loc-gray4-2" :src="require ('@/assets/images/master stokis/location-grey.png')" alt="">
                </div>

                <div class="col-lg-4 col-md-6 col-10">
                    <div class="text-center wow fadeInLeft" data-wow-delay="200ms">
                        <h5 class="font-weight-bold mb-3 mt-5 mt-md-0">MASTER STOKIS PROVINSI SULAWESI</h5>
                        <div class="card-artikel mb-5">
                            <div class="card-body">
                                <iframe class="img-fluid"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.333064545007!2d119.86160771446745!3d-0.8936157993481122!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2d8bedc606e702d5%3A0xdee2560bd39c585f!2s121%2C%20Jl.%20Lorong%20Bakso%20No.2%2C%20Baru%2C%20Kec.%20Palu%20Bar.%2C%20Kota%20Palu%2C%20Sulawesi%20Tengah%2094111!5e0!3m2!1sen!2sid!4v1621497190422!5m2!1sen!2sid"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                <h3 class="font-weight-bold mt-3">SULAWESI TENGAH</h3>
                                <p class="text-ijo">Bapak Andi Jamalullail</p>
                                <p class="text-abumuda">Jl. Dr.Wahidin Lorong Bakso 2 No.121 Kel.Besusu Barat Kec.Palu Timur
                                    Kota Palu Sulawesi Tengah</p>
                                <p class="text-abu font-weight-bold">085679841273</p>
                                <div class="mt-4 mb-2">
                                    <a href="" class="btn-bg-ijo rounded-15 py-2 px-4"><i
                                            class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 offset-lg-1 d-md-block d-none wow fadeInRight" data-wow-delay="400ms">
                    <img class="img-fluid" :src="require ('@/assets/images/master stokis/sulawesi-tengah.png')" alt="">
                    <img class="img-fluid loc-gray4-1" :src="require ('@/assets/images/master stokis/location-grey.png')" alt="">
                    <img class="img-fluid loc-gray4-2" :src="require ('@/assets/images/master stokis/location-grey.png')" alt="">
                </div>
            </div>
        </div>

        <!-- Backgroung 3-4 -->
        <div class="offset-10 col-2 z bg-1-2 mt d-lg-block d-none wow fadeInRight">
            <img class="img-bg-kanan" :src="require ('@/assets/images/beranda/bg-section-5-6.png')" alt="">
        </div>

        <div class="container -mt-section-2">
            <div class="row align-items-center justify-content-center">
                <div class="col-lg-7 col-md-6 mt-7 wow fadeInLeft" data-wow-delay="200ms">
                    <img class="img-fluid" :src="require ('@/assets/images/master stokis/papua.png')" alt="">
                    <img class="img-fluid loc5" :src="require ('@/assets/images/master stokis/location.png')" alt="">
                </div>
                <div class="col-lg-4 col-md-6 col-10">
                    <div class="text-center wow fadeInRight" data-wow-delay="400ms">
                        <h5 class="font-weight-bold mb-3 mt-5 mt-md-0">MASTER STOKIS PROVINSI PAPUA</h5>
                        <div class="card-artikel mb-5">
                            <div class="card-body">
                                <iframe class="img-fluid"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3977.2686616698074!2d136.88441261447645!3d-4.545596996697381!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6823773fe47ff375%3A0x136728ec60333b83!2sJl.%20Mambruk%2C%20Kwamki%2C%20Kec.%20Mimika%20Baru%2C%20Kabupaten%20Mimika%2C%20Papua%2099971!5e0!3m2!1sen!2sid!4v1621498216241!5m2!1sen!2sid"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                <h3 class="font-weight-bold mt-3">PROVINSI PAPUA</h3>
                                <p class="text-ijo">Bapak Elias Sianipar</p>
                                <p class="text-abumuda">Jl.Mambruk RT25 Kel.Kwamki Kec.Mimika Baru Kota Mimika Kab.Timika
                                    Papua</p>
                                <p class="text-abu font-weight-bold">085679841273</p>
                                <div class="mt-4 mb-2">
                                    <a href="" class="btn-bg-ijo rounded-15 py-2 px-4"><i
                                            class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END MASTER -->

        <!-- Backgroung 6-7 -->
        <div class="z bg-1-2 wow fadeInUp ">
            <img class="img-bg-2" :src="require ('@/assets/images/beranda/bg-section-6-7.png')" alt="">
        </div>

        <Banner/>
    </div>
</template>

<script>
import Banner from '../components/Banner.vue'

export default {
    name: 'Masterstokis',
    components: {
        Banner
    }
}
</script>