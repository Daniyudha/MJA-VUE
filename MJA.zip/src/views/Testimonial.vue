<template>
    <div class="testimonial">
        <!-- Background -->
        <div class="z offset-lg-6 col-lg-6 offset-md-4 col-md-8 -mt-n wow fadeInRight">
            <img class="mt-bg" :src="require ('@/assets/images/beranda/bg-section-1.png')" alt="">
        </div>

        <!-- START TESTI CAROUSAL -->
        <div class="container sec-stokis">
            <div class="text-center">
                <h2 class="font-weight-bold l-s wow fadeInDown" data-wow-delay="200ms">TESTIMONIAL</h2>
                <h4 class="text-abumuda wow fadeInDown" data-wow-delay="400ms">MENURUT YANG SUDAH MENGGUNAKAN PRODUK KAMI</h4>
            </div>

            <div id="carrousel">
                <div class="container wow fadeIn" data-wow-delay="600ms">
                    <div class="col-md-12">
                        <div class="owl-carousel testi-carousel">
                            <div class="item">
                                <div class="testi-carousel">
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-md-4 d-md-block d-none">
                                                <img class="img-fluid" :src="require ('@/assets/images/testimoni/bg-profile-picture.png')"
                                                    alt="">
                                                <img class="-mt-profil img-fluid" :src="require ('@/assets/images/testimoni/1.png')"
                                                    alt="">
                                            </div>
                                            <div class="col-md-8 col-12">
                                                <div>
                                                    <p class="des-testi">"Proin euismod sit amet nisl non congue. Aliquam
                                                        cursus turpis at
                                                        vulputate aliquet. Fusce quis dui at lorem ultrices varius. Aenean
                                                        pulvinar enim at dapibus luctus. Phasellus eleifend leo quis luctus
                                                        tincidunt. Sed congue ex eu facilisis placerat." </p>
                                                </div>
                                                <div class="mt-4 d-md-block d-none">
                                                    <p class="text-ijo my-0">John Lorem Doe</p>
                                                    <p class="text-abumuda">Semarang</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-1 align-items-center d-md-none ">
                                            <div class="col-5">
                                                <img class="img-fluid"
                                                    :src="require ('@/assets/images/testimoni/bg-profile-picture.png')" alt="">
                                                <img class="-mt-profil img-fluid"
                                                    :src="require ('@/assets/images/testimoni/1.png')" alt="">
                                            </div>
                                            <div class="col-7">
                                                <p class="text-ijo name my-0">John Lorem </p>
                                                <p class="text-abumuda name">Semarang</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div class="testi-carousel">
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-md-4 d-md-block d-none">
                                                <img class="img-fluid" :src="require ('@/assets/images/testimoni/bg-profile-picture.png')"
                                                    alt="">
                                                <img class="-mt-profil img-fluid" :src="require ('@/assets/images/testimoni/1.png')"
                                                    alt="">
                                            </div>
                                            <div class="col-md-8 col-12">
                                                <div>
                                                    <p class="des-testi">"Proin euismod sit amet nisl non congue. Aliquam
                                                        cursus turpis at
                                                        vulputate aliquet. Fusce quis dui at lorem ultrices varius. Aenean
                                                        pulvinar enim at dapibus luctus. Phasellus eleifend leo quis luctus
                                                        tincidunt. Sed congue ex eu facilisis placerat." </p>
                                                </div>
                                                <div class="mt-4 d-md-block d-none">
                                                    <p class="text-ijo my-0">John Lorem Doe</p>
                                                    <p class="text-abumuda">Semarang</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-1 align-items-center d-md-none ">
                                            <div class="col-5">
                                                <img class="img-fluid"
                                                    :src="require ('@/assets/images/testimoni/bg-profile-picture.png')" alt="">
                                                <img class="-mt-profil img-fluid"
                                                    :src="require ('@/assets/images/testimoni/1.png')" alt="">
                                            </div>
                                            <div class="col-7">
                                                <p class="text-ijo name my-0">John Lorem </p>
                                                <p class="text-abumuda name">Semarang</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div class="testi-carousel">
                                    <div class="card-body">
                                        <div class="row align-items-center">
                                            <div class="col-md-4 d-md-block d-none">
                                                <img class="img-fluid" :src="require ('@/assets/images/testimoni/bg-profile-picture.png')"
                                                    alt="">
                                                <img class="-mt-profil img-fluid" :src="require ('@/assets/images/testimoni/1.png')"
                                                    alt="">
                                            </div>
                                            <div class="col-md-8 col-12">
                                                <div>
                                                    <p class="des-testi">"Proin euismod sit amet nisl non congue. Aliquam
                                                        cursus turpis at
                                                        vulputate aliquet. Fusce quis dui at lorem ultrices varius. Aenean
                                                        pulvinar enim at dapibus luctus. Phasellus eleifend leo quis luctus
                                                        tincidunt. Sed congue ex eu facilisis placerat." </p>
                                                </div>
                                                <div class="mt-4 d-md-block d-none">
                                                    <p class="text-ijo my-0">John Lorem Doe</p>
                                                    <p class="text-abumuda">Semarang</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mt-1 align-items-center d-md-none ">
                                            <div class="col-5">
                                                <img class="img-fluid"
                                                    :src="require ('@/assets/images/testimoni/bg-profile-picture.png')" alt="">
                                                <img class="-mt-profil img-fluid"
                                                    :src="require ('@/assets/images/testimoni/1.png')" alt="">
                                            </div>
                                            <div class="col-7">
                                                <p class="text-ijo name my-0">John Lorem </p>
                                                <p class="text-abumuda name">Semarang</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END TESTI CAROUSAL -->

        <!-- START TESTIMONIAL -->
        <div class="container">
            <div class="row mt-5 align-items-center wow fadeInLeft">
                <div class="col-lg-3 col-md-4 d-md-block d-none">
                    <img class="rounded-15" :src="require ('@/assets/images/testimoni/2.png')" alt="">
                </div>
                <div class="col-lg-9 offset-lg-0 col-md-7 offset-md-1">
                    <div class="card-testi">
                        <div class="card-body">
                            <div class="d-md-none d-block">
                                <img class="rounded w-100 mb-3" :src="require ('@/assets/images/testimoni/2.png')" alt="">
                            </div>
                            <h5 class="font-weight-bold">"Saya bisa menambah pendapatan harian dengan bergabung"</h5>
                            <div class="garis-verikal">
                                <p class="ml-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed
                                    porttitor nunc. Duis in augue condimentum lacus ultrices pretium. Nulla facilisi. Fusce
                                    eleifend commodo condimentum. Nulla tempor erat nisl, tristique elementum libero egestas
                                    a.</p>
                            </div>
                            <div>
                                <p class="text-ijo my-0">Nanang</p>
                                <p class="text-abumuda">Yogyakarta</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-5 align-items-center wow fadeInRight" data-wow-delay="100ms">
                <div class="col-lg-9 col-md-7">
                    <div class="card-testi">
                        <div class="card-body">
                            <div class="d-md-none d-block">
                                <img class="rounded w-100 mb-3" :src="require ('@/assets/images/testimoni/3.png')" alt="">
                            </div>
                            <h5 class="font-weight-bold">"Sistem bonus harian yang sangat menggiurkan"</h5>
                            <div class="garis-verikal">
                                <p class="ml-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed
                                    porttitor nunc. Duis in augue condimentum lacus ultrices pretium. Nulla facilisi. Fusce
                                    eleifend commodo condimentum. Nulla tempor erat nisl, tristique elementum libero egestas
                                    a.</p>
                            </div>
                            <div>
                                <p class="text-ijo my-0">Sheila Firmansyah</p>
                                <p class="text-abumuda">Sumedang</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 d-md-block d-none">
                    <img class="rounded-15" :src="require ('@/assets/images/testimoni/3.png')" alt="">
                </div>
            </div>

            <div class="row mt-5 align-items-center wow fadeInLeft" data-wow-delay="200ms">
                <div class="col-lg-3 col-md-4 d-md-block d-none">
                    <img class="rounded-15" :src="require ('@/assets/images/testimoni/4.png')" alt="">
                </div>
                <div class="col-lg-9 offset-lg-0 col-md-7 offset-md-1">
                    <div class="card-testi">
                        <div class="card-body">
                            <div class="d-md-none d-block">
                                <img class="rounded w-100 mb-3" :src="require ('@/assets/images/testimoni/4.png')" alt="">
                            </div>
                            <h5 class="font-weight-bold">"Produk yang mudah didapatkan dan terjangkau"</h5>
                            <div class="garis-verikal">
                                <p class="ml-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed
                                    porttitor nunc. Duis in augue condimentum lacus ultrices pretium. Nulla facilisi. Fusce
                                    eleifend commodo condimentum. Nulla tempor erat nisl, tristique elementum libero egestas
                                    a.</p>
                            </div>
                            <div>
                                <p class="text-ijo my-0">Nanang</p>
                                <p class="text-abumuda">Yogyakarta</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-5 align-items-center wow fadeInRight" data-wow-delay="300ms">
                <div class="col-lg-9 col-md-7">
                    <div class="card-testi">
                        <div class="card-body">
                            <div class="d-md-none d-block">
                                <img class="rounded w-100 mb-3" :src="require ('@/assets/images/testimoni/5.png')" alt="">
                            </div>
                            <h5 class="font-weight-bold">"Banyak orang yang mendapatkan manfaat dari produk MJA"</h5>
                            <div class="garis-verikal">
                                <p class="ml-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed
                                    porttitor nunc. Duis in augue condimentum lacus ultrices pretium. Nulla facilisi. Fusce
                                    eleifend commodo condimentum. Nulla tempor erat nisl, tristique elementum libero egestas
                                    a.</p>
                            </div>
                            <div>
                                <p class="text-ijo my-0">Sheila Firmansyah</p>
                                <p class="text-abumuda">Sumedang</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 d-md-block d-none">
                    <img class="rounded-15" :src="require ('@/assets/images/testimoni/5.png')" alt="">
                </div>
            </div>

            <div class="row mt-5 align-items-center wow fadeInLeft" data-wow-delay="400ms">
                <div class="col-lg-3 col-md-4 d-md-block d-none">
                    <img class="rounded-15" :src="require ('@/assets/images/testimoni/6.png')" alt="">
                </div>
                <div class="col-lg-9 offset-lg-0 col-md-7 offset-md-1">
                    <div class="card-testi">
                        <div class="card-body">
                            <div class="d-md-none d-block">
                                <img class="rounded w-100 mb-3" :src="require ('@/assets/images/testimoni/6.png')" alt="">
                            </div>
                            <h5 class="font-weight-bold">"Produknya sangat membantu dalam proses penyembuhan"</h5>
                            <div class="garis-verikal">
                                <p class="ml-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed
                                    porttitor nunc. Duis in augue condimentum lacus ultrices pretium. Nulla facilisi. Fusce
                                    eleifend commodo condimentum. Nulla tempor erat nisl, tristique elementum libero egestas
                                    a.</p>
                            </div>
                            <div>
                                <p class="text-ijo my-0">Nanang</p>
                                <p class="text-abumuda">Yogyakarta</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-5 align-items-center wow fadeInRight" data-wow-delay="500ms">
                <div class="col-lg-9 col-md-7">
                    <div class="card-testi">
                        <div class="card-body">
                            <div class="d-md-none d-block">
                                <img class="rounded w-100 mb-3" :src="require ('@/assets/images/testimoni/3.png')" alt="">
                            </div>
                            <h5 class="font-weight-bold">"Sistem bonus harian yang sangat menggiurkan"</h5>
                            <div class="garis-verikal">
                                <p class="ml-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed
                                    porttitor nunc. Duis in augue condimentum lacus ultrices pretium. Nulla facilisi. Fusce
                                    eleifend commodo condimentum. Nulla tempor erat nisl, tristique elementum libero egestas
                                    a.</p>
                            </div>
                            <div>
                                <p class="text-ijo my-0">Sheila Firmansyah</p>
                                <p class="text-abumuda">Sumedang</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 d-md-block d-none">
                    <img class="rounded-15" :src="require ('@/assets/images/testimoni/3.png')" alt="">
                </div>
            </div>

            <div class="row mt-5 align-items-center wow fadeInLeft" data-wow-delay="600ms">
                <div class="col-lg-3 col-md-4 d-md-block d-none">
                    <img class="rounded-15" :src="require ('@/assets/images/testimoni/4.png')" alt="">
                </div>
                <div class="col-lg-9 offset-lg-0 col-md-7 offset-md-1">
                    <div class="card-testi">
                        <div class="card-body">
                            <div class="d-md-none d-block">
                                <img class="rounded w-100 mb-3" :src="require ('@/assets/images/testimoni/4.png')" alt="">
                            </div>
                            <h5 class="font-weight-bold">"Banyak orang yang mendapatkan manfaat dari produk MJA"</h5>
                            <div class="garis-verikal">
                                <p class="ml-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed
                                    porttitor nunc. Duis in augue condimentum lacus ultrices pretium. Nulla facilisi. Fusce
                                    eleifend commodo condimentum. Nulla tempor erat nisl, tristique elementum libero egestas
                                    a.</p>
                            </div>
                            <div>
                                <p class="text-ijo my-0">Nanang</p>
                                <p class="text-abumuda">Yogyakarta</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-5 align-items-center wow fadeInRight" data-wow-delay="700ms">
                <div class="col-lg-9 col-md-7">
                    <div class="card-testi">
                        <div class="card-body">
                            <div class="d-md-none d-block">
                                <img class="rounded w-100 mb-3" :src="require ('@/assets/images/testimoni/5.png')" alt="">
                            </div>
                            <h5 class="font-weight-bold">"Produk yang mudah didapatkan dan terjangkau"</h5>
                            <div class="garis-verikal">
                                <p class="ml-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed
                                    porttitor nunc. Duis in augue condimentum lacus ultrices pretium. Nulla facilisi. Fusce
                                    eleifend commodo condimentum. Nulla tempor erat nisl, tristique elementum libero egestas
                                    a.</p>
                            </div>
                            <div>
                                <p class="text-ijo my-0">Sheila Firmansyah</p>
                                <p class="text-abumuda">Sumedang</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 d-md-block d-none">
                    <img class="rounded-15" :src="require ('@/assets/images/testimoni/5.png')" alt="">
                </div>
            </div>
        </div>
        <!-- END TESTIMONIAL -->

        <div class="container mt-3">
            <div class="text-center wow fadeInUp" data-wow-delay="800ms">
                <ul class="pg">
                    <li>
                        <a href="">1</a>
                    </li>
                    <li>
                        <a href="">2</a>
                    </li>
                    <li>
                        <a href="">3</a>
                    </li>
                    <li>
                        <a href="">...</a>
                    </li>
                    <li>
                        <a href="">10</a>
                    </li>
                    <li>
                        <a href=""><i class="fas fa-chevron-right"></i></a>
                    </li>
                </ul>
            </div>
        </div>


        <!-- Background -->
        <div class="float-right z aksen wow fadeInUp">
            <img class="" :src="require ('@/assets/images/testimoni/bg-section-5.png')" alt="">
        </div>
    </div>
</template>

<style scoped>
.aksen{
    margin-top: -220px;
}
</style>