<template>
    <div class="stokis">
        <!-- Background -->
        <div class="z offset-lg-6 col-lg-6 offset-md-4 col-md-8 -mt-n wow fadeInRight">
            <img class="mt-bg" :src="require ('@/assets/images/beranda/bg-section-1.png')" alt="">
        </div>

        <!-- START DAFTAR STOKIS -->
        <div class="sec-stokis ">
            <div class="container">
                <div class="text-center mb-5">
                    <img class="img-fluid wow fadeInDown" data-wow-delay="300ms" :src="require ('@/assets/images/daftar stokis/ilus-daftar-stokis-mja.png')" alt="">
                    <h3 class="font-weight-bold l-s wow fadeInUp" data-wow-delay="500ms">DAFTAR STOKIS MJA</h3>
                    <h6 class="text-abumuda wow fadeInUp" data-wow-delay="700ms">DAFTAR LOKASI STOKIS UNTUK MJA</h6>
                </div>
            </div>
        </div>
        <!-- END DAFTAR STOKIS -->

        <!-- START CARD -->
        <div class="container">
            <div class="row justify-content-center justify-content-lg-start wow fadeIn" data-wow-delay="1000ms">
                <div class="col-lg-4 col-md-6 col-10">
                    <div class="card-artikel mb-5">
                        <div class="card-body">
                            <div class="text-center">
                                <iframe class="img-fluid"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1982.5582832586958!2d106.80194645795024!3d-6.378951298846035!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69eeb3aadf609d%3A0x23b524363aff51b6!2sJl.%20Delima%20V%20Blok%20N%2C%20Tanah%20Baru%2C%20Kecamatan%20Beji%2C%20Kota%20Depok%2C%20Jawa%20Barat%2016426!5e0!3m2!1sen!2sid!4v1621491520681!5m2!1sen!2sid"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                <h3 class="font-weight-bold mt-3">STOKIS 01 KOTA DEPOK</h3>
                                <p class="text-ijo">Ibu Titin Rohmah</p>
                                <p class="text-abumuda">Komplek Beji Permai Jl. Delima V Blok N (depan N6) Tanah Baru
                                    Kota Depok</p>
                                <p class="text-abu font-weight-bold">081387635761</p>
                                <div class="mt-4 mb-2">
                                    <a href="" class="btn-bg-ijo rounded-15 py-2 px-4"><i
                                            class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-10">
                    <div class="card-artikel mb-5">
                        <div class="card-body">
                            <div class="text-center">
                                <iframe class="img-fluid"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15933.867012154875!2d127.07714422219759!3d-3.2333979123338072!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2d7212de4c156693%3A0xe52ca57740e74df!2sNamlea%2C%20Buru%20Regency%2C%20Maluku!5e0!3m2!1sen!2sid!4v1621484524109!5m2!1sen!2sid"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                <h3 class="font-weight-bold mt-3">STOKIS 02 KOTA NAMLEA</h3>
                                <p class="text-ijo">Bapak Imami Junaldy M, S.Pd.</p>
                                <p class="text-abumuda">Jl. Bupati-Pal 2 RT02 RW02 Kel. Namlea Kec. Namlea Kota Baru
                                    Maluku</p>
                                <p class="text-abu font-weight-bold">082455873451</p>
                                <div class="mt-4 mb-2">
                                    <a href="" class="btn-bg-ijo rounded-15 py-2 px-4"><i
                                            class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-10">
                    <div class="card-artikel mb-5">
                        <div class="card-body">
                            <div class="text-center">
                                <iframe class="img-fluid"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3961.27957485129!2d107.52080368800893!3d-6.857056396415779!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68e486584fca77%3A0x9018f54cdde8e5e1!2sJl.%20Permata%20Cimahi%20II%2C%20Tanimulya%2C%20Kec.%20Ngamprah%2C%20Kabupaten%20Bandung%20Barat%2C%20Jawa%20Barat%2040552!5e0!3m2!1sen!2sid!4v1621491277171!5m2!1sen!2sid"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                <h3 class="font-weight-bold mt-3">STOKIS 03 KOTA BANDUNG</h3>
                                <p class="text-ijo">Ibu Dr. Ina</p>
                                <p class="text-abumuda">Perum Graha Puspa B3 No.7C Sukajaya Lembang Bandung Barat</p>
                                <p class="text-abu font-weight-bold">08129833628990</p>
                                <div class="mt-4 mb-2">
                                    <a href="" class="btn-bg-ijo rounded-15 py-2 px-4"><i
                                            class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-10">
                    <div class="card-artikel mb-5">
                        <div class="card-body">
                            <div class="text-center">
                                <iframe class="img-fluid"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3961.27957485129!2d107.52080368800895!3d-6.857056396415779!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68e486584fca77%3A0x9018f54cdde8e5e1!2sJl.%20Permata%20Cimahi%20II%2C%20Tanimulya%2C%20Kec.%20Ngamprah%2C%20Kabupaten%20Bandung%20Barat%2C%20Jawa%20Barat%2040552!5e0!3m2!1sen!2sid!4v1621491222739!5m2!1sen!2sid"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                <h3 class="font-weight-bold mt-3">STOKIS 04 KOTA CIMAHI</h3>
                                <p class="text-ijo">Bapak Yoyok Barkah</p>
                                <p class="text-abumuda">Permata Cimahi B1 No.15 RT001 Kec. Ngamprah Kota Cimahi</p>
                                <p class="text-abu font-weight-bold">089765324109</p>
                                <div class="mt-4 mb-2">
                                    <a href="" class="btn-bg-ijo rounded-15 py-2 px-4"><i
                                            class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-10">
                    <div class="card-artikel mb-5">
                        <div class="card-body">
                            <div class="text-center">
                                <iframe class="img-fluid"
                                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15845.15618886754!2d107.90968522246338!3d-6.855916970726677!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68d117ed696343%3A0x9d883814b69a4d16!2sRegol%20Wetan%2C%20Sumedang%20Selatan%2C%20Sumedang%20Regency%2C%20West%20Java!5e0!3m2!1sen!2sid!4v1621491348783!5m2!1sen!2sid"
                                    width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                                <h3 class="font-weight-bold mt-3">STOKIS 05 KOTA SUMEDANG</h3>
                                <p class="text-ijo">Ibu Lilik</p>
                                <p class="text-abumuda">Lingkungan Gunung China No.7 RT02 RW04 Regol Weton Kota Sumedang
                                </p>
                                <p class="text-abu font-weight-bold">08157653987</p>
                                <div class="mt-4 mb-2">
                                    <a href="" class="btn-bg-ijo rounded-15 py-2 px-4"><i
                                            class="fab fa-whatsapp mr-2"></i>Whatsapp</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- END CARD -->

        <!-- Backgroung 6-7 -->
        <div class="z bg-1-2 wow fadeInUp">
            <img class="img-bg-2" :src="require ('@/assets/images/beranda/bg-section-6-7.png')" alt="">
        </div>

        <Banner/>
    </div>
</template>

<script>
import Banner from '../components/Banner.vue'

export default {
    name: 'Stokis',
    components: {
        Banner
    }
}
</script>