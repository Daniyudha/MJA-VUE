<template>
    <div class="gallery-download">
        <!-- Background -->
        <div class="z offset-lg-6 col-lg-6 offset-md-4 col-md-8 -mt-n wow fadeInRight">
            <img class="mt-bg" :src="require ('@/assets/images/beranda/bg-section-1.png')" alt="">
        </div>

        <!-- START DOWNLOAD -->
        <div class="container sec-kontak">
            <h3 class="l-s mb-4 wow fadeInDown" data-wow-delay="200ms">DOWNLOAD</h3>
            <div class="row justify-content-center wow fadeIn" data-wow-delay="500ms">
                <div class="col-lg-3 col-md-6 col-6 mb-4">
                    <img class="mklbItem rounded-15 img-fluid" :src="require ('@/assets/images/gallery/video-thumbnail-1.png')"
                        data-src="assets/images/gallery/video-thumbnail-1.png" data-gallery="gallery1" />
                </div>
                <div class="col-lg-3 col-md-6 col-6 mb-4">
                    <img class="mklbItem rounded-15 img-fluid" :src="require ('@/assets/images/gallery/video-thumbnail-2.png')"
                        data-src="assets/images/gallery/video-thumbnail-2.png" data-gallery="gallery1" />
                </div>
                <div class="col-lg-3 col-md-6 col-6 mb-4">
                    <img class="mklbItem rounded-15 img-fluid" :src="require ('@/assets/images/gallery/video-thumbnail-7.png')"
                        data-src="assets/images/gallery/video-thumbnail-7.png" data-gallery="gallery1" />
                </div>
                <div class="col-lg-3 col-md-6 col-6 mb-4">
                    <img class="mklbItem rounded-15 img-fluid" :src="require ('@/assets/images/gallery/video-thumbnail-4.png')"
                        data-src="assets/images/gallery/video-thumbnail-4.png" data-gallery="gallery1" />
                </div>
                <div class="col-lg-3 col-md-6 col-6 mb-4">
                    <img class="mklbItem rounded-15 img-fluid" :src="require ('@/assets/images/gallery/video-thumbnail-1.png')"
                        data-src="assets/images/gallery/video-thumbnail-1.png" data-gallery="gallery1" />
                </div>
                <div class="col-lg-3 col-md-6 col-6 mb-4">
                    <img class="mklbItem rounded-15 img-fluid" :src="require ('@/assets/images/gallery/video-thumbnail-2.png')"
                        data-src="assets/images/gallery/video-thumbnail-2.png" data-gallery="gallery1" />
                </div>
                <div class="col-lg-3 col-md-6 col-6 mb-4">
                    <img class="mklbItem rounded-15 img-fluid" :src="require ('@/assets/images/gallery/video-thumbnail-7.png')"
                        data-src="assets/images/gallery/video-thumbnail-7.png" data-gallery="gallery1" />
                </div>
                <div class="col-lg-3 col-md-6 col-6 mb-4">
                    <img class="mklbItem rounded-15 img-fluid" :src="require ('@/assets/images/gallery/video-thumbnail-4.png')"
                        data-src="assets/images/gallery/video-thumbnail-4.png" data-gallery="gallery1" />
                </div>
            </div>
        </div>
        <!-- END DOWNLOAD -->
    </div>
</template>